minetest.register_on_respawnplayer(function(player)
    player:setpos({x=429.7, y=60.0, z=258.2})
    return true
end)
